# Fixing and writing workflow JSON again

import json
from pathlib import Path

orig_path = Path("/mnt/data/My workflow.json")
orig = {}
if orig_path.exists():
    orig = json.loads(orig_path.read_text())

workflow = {
    "name": "WhatsApp FactCheck Workflow (n8n)",
    "nodes": [
        {
            "parameters": {
                "path": "twilio-webhook",
                "httpMethod": "POST",
                "responseMode": "onReceived",
                "options": {}
            },
            "name": "Webhook (Twilio)",
            "type": "n8n-nodes-base.webhook",
            "typeVersion": 1,
            "position": [250, 300]
        },
        {
            "parameters": {
                "functionCode": """// Normalize Twilio webhook payload (form-urlencoded). 
// Twilio sends Body, From, NumMedia, MediaUrl0... MediaUrlN if media present.
// Input: webhook JSON
const body = $json;
const messageText = body.Body || "";
const from = body.From || "";
const numMedia = parseInt(body.NumMedia || "0", 10) || 0;
let mediaUrls = [];
for (let i = 0; i < numMedia; i++) {
  const key = `MediaUrl${i}`;
  if (body[key]) mediaUrls.push(body[key]);
}
return [{
  json: {
    raw: body,
    messageText,
    from,
    numMedia,
    mediaUrls,
    timestamp: new Date().toISOString()
  }
}];"""
            },
            "name": "Normalize Message",
            "type": "n8n-nodes-base.function",
            "typeVersion": 1,
            "position": [520, 300]
        },
        {
            "parameters": {
                "requestMethod": "GET",
                "url": "https://factchecktools.googleapis.com/v1alpha1/claims:search",
                "queryParametersUi": {
                    "parameter": [
                        {
                            "name": "query",
                            "value": "={{$json[\"messageText\"]}}"
                        },
                        {
                            "name": "languageCode",
                            "value": "en"
                        },
                        {
                            "name": "key",
                            "value": "AIzaSyA24xULz3DgBkKAdsXfu-89-obvtCijegc"
                        }
                    ]
                },
                "options": {}
            },
            "name": "Google Fact Check",
            "type": "n8n-nodes-base.httpRequest",
            "typeVersion": 1,
            "position": [800, 240]
        },
        {
            "parameters": {
                "functionCode": """// Parse Fact Check API response and produce verdict, explanation, confidence
const resp = $json || {};
const results = resp.claims || [];
let verdict = "UNKNOWN";
let explanation = "";
let sources = [];
let score = 25;

if (results.length === 0) {
  verdict = "UNKNOWN";
  explanation = "No matching fact-checks found in Google Fact Check Tools for the submitted text. This does not prove the claim is true — it means no published ClaimReview matched our query.";
  score = 25;
} else {
  const top = results[0];
  const reviews = top.claimReview || [];
  sources = reviews.map(r => ({
    publisher: r.publisher && r.publisher.name,
    url: r.url,
    rating: r.textualRating
  }));
  const ratings = reviews.map(r => (r.textualRating || "").toLowerCase());
  if (ratings.some(r => r.includes("false") || r.includes("misleading"))) verdict = "FALSE";
  else if (ratings.some(r => r.includes("true") || r.includes("correct"))) verdict = "TRUE";
  else if (ratings.some(r => r.includes("mixt") || r.includes("partly") || r.includes("partly"))) verdict = "MIXED";
  else verdict = "UNKNOWN";

  const topReview = reviews[0] || {};
  explanation = `Fact-check by ${topReview.publisher && topReview.publisher.name || "a publisher"} (${topReview.reviewDate || "date unknown"}) concluded: ${topReview.textualRating || "rating not given"}. Summary: ${topReview.title || topReview.excerpt || top.claimReviewed || "No summary available."} Read more: ${topReview.url || "N/A"}`;
  score = 60 + Math.min(30, (new Set(sources.map(s => s.publisher)).size - 1) * 10);
  if (verdict === "UNKNOWN") score = 40;
}

return [{
  json: {
    verdict,
    explanation,
    sources,
    confidence_score: score,
    original_text: $json.messageText || null,
    sender: $json.from || null,
    timestamp: new Date().toISOString()
  }
}];"""
            },
            "name": "Parse FactCheck",
            "type": "n8n-nodes-base.function",
            "typeVersion": 1,
            "position": [1060, 240]
        },
        {
            "parameters": {
                "operation": "append",
                "sheetId": "YOUR_GOOGLE_SHEET_ID_HERE",
                "range": "Sheet1!A1:G1",
                "valueInputMode": "RAW",
                "options": {},
                "columnsUi": {
                    "column": [
                        {
                            "columnId": "Timestamp",
                            "value": "={{$json[\"timestamp\"]}}"
                        },
                        {
                            "columnId": "Sender",
                            "value": "={{$json[\"sender\"]}}"
                        },
                        {
                            "columnId": "Message",
                            "value": "={{$json[\"original_text\"]}}"
                        },
                        {
                            "columnId": "Verdict",
                            "value": "={{$json[\"verdict\"]}}"
                        },
                        {
                            "columnId": "Explanation",
                            "value": "={{$json[\"explanation\"]}}"
                        },
                        {
                            "columnId": "Sources",
                            "value": "={{JSON.stringify($json[\"sources\"])}}"
                        },
                        {
                            "columnId": "Confidence",
                            "value": "={{$json[\"confidence_score\"]}}"
                        }
                    ]
                }
            },
            "name": "Google Sheets Append",
            "type": "n8n-nodes-base.googleSheets",
            "typeVersion": 1,
            "position": [1340, 240],
            "credentials": {
                "googleSheetsOAuth2": {
                    "id": "GOOGLE_SHEETS_OAUTH_CREDENTIAL_ID",
                    "name": "googleSheetsOAuth2"
                }
            }
        },
        {
            "parameters": {
                "requestMethod": "POST",
                "url": "https://api.twilio.com/2010-04-01/Accounts/US597be17502493697db96575ab77b0412/Messages.json",
                "jsonParameters": True,
                "options": {},
                "headerParametersUi": {
                    "parameter": []
                },
                "bodyParametersJson": "{\"To\":\"={{$json[\"sender\"]}}\",\"From\":\"whatsapp:+14155238886\",\"Body\":\"Verdict: {{$json[\"verdict\"]}}\\nConfidence: {{$json[\"confidence_score\"]}}\\nShort reason: {{$json[\"explanation\"].slice(0,300)}}\\nDetails saved to Google Sheet.\"}"
            },
            "name": "Reply via Twilio",
            "type": "n8n-nodes-base.httpRequest",
            "typeVersion": 1,
            "position": [1600, 300],
            "credentials": {
                "httpBasicAuth": {
                    "id": "twilio_basic_auth",
                    "name": "twilio_basic_auth"
                }
            }
        }
    ],
    "connections": {
        "Webhook (Twilio)": {
            "main": [
                [
                    {
                        "node": "Normalize Message",
                        "type": "main",
                        "index": 0
                    }
                ]
            ]
        },
        "Normalize Message": {
            "main": [
                [
                    {
                        "node": "Google Fact Check",
                        "type": "main",
                        "index": 0
                    }
                ]
            ]
        },
        "Google Fact Check": {
            "main": [
                [
                    {
                        "node": "Parse FactCheck",
                        "type": "main",
                        "index": 0
                    }
                ]
            ]
        },
        "Parse FactCheck": {
            "main": [
                [
                    {
                        "node": "Google Sheets Append",
                        "type": "main",
                        "index": 0
                    },
                    {
                        "node": "Reply via Twilio",
                        "type": "main",
                        "index": 0
                    }
                ]
            ]
        }
    },
    "active": False,
    "settings": {
        "executionOrder": "v1"
    },
    "meta": orig.get("meta", {})
}

# Add credentials placeholder; include Twilio basic auth with provided creds (user supplied)
workflow["credentials"] = {
    "httpBasicAuth": {
        "id": "twilio_basic_auth",
        "name": "twilio_basic_auth",
        "data": {
            "user": "US597be17502493697db96575ab77b0412",
            "password": "AC14ed89ceab55469b1a8282549b6a9943"
        }
    },
    "googleSheetsOAuth2": {
        "id": "GOOGLE_SHEETS_OAUTH_CREDENTIAL_ID",
        "name": "googleSheetsOAuth2",
        "data": {}
    }
}

out_path = Path("./workflow-filled.json")
out_path.write_text(json.dumps(workflow, indent=2))
str(out_path)

