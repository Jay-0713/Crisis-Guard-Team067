# app.py
import os
import re
import requests
from flask import Flask, request
from twilio.twiml.messaging_response import MessagingResponse
import datetime
from dateutil import parser as dateparser  # ensure python-dateutil installed
import io
import hashlib
import json
import time
from PIL import Image, ExifTags
import imagehash
import tldextract
import base64
import uuid

from data_store import (
    log_text_entry,
    log_image_entry,
    log_url_entry,
    save_image_file,
    save_analysis_text,
)

# --- CONFIG ---
FACTCHECK_API_KEY = os.getenv("FACTCHECK_API_KEY")  # Leave empty if not using
GSAFE_API_KEY = os.getenv("GSAFE_API_KEY")          # Google Safe Browsing API Key (optional)
VISION_API_KEY = os.getenv("VISION_API_KEY")        # Google Vision API Key (REST)
URL_RE = re.compile(r'https?://\S+')

app = Flask(__name__)

# small DB of known hoax image pHashes (hex strings) -> fill with real data later
KNOWN_IMAGE_HASHES = {
    # "a1b2c3d4...": {"label":"fake-certificate","source":"altnews","url":"https://..."}
}


# ------------ GOOGLE FACT CHECK TOOL ------------
def query_google_factchecks(query_text):
    """Check a claim using Google Fact Check Tools API."""
    if not FACTCHECK_API_KEY:
        return None
    url = "https://factchecktools.googleapis.com/v1alpha1/claims:search"
    params = {"query": query_text, "key": FACTCHECK_API_KEY}
    try:
        r = requests.get(url, params=params, timeout=8)
        r.raise_for_status()
        return r.json()
    except Exception as e:
        print("FactCheck API error:", e)
        return None


def compute_confidence_from_factcheck(fc_json):
    """
    Return an integer confidence 0-100 and a short explanation list.
    """
    claims = fc_json.get("claims", []) if fc_json else []
    if not claims:
        return 25, ["No authoritative fact-check found (baseline low confidence)."]

    best = claims[0]
    reviews = best.get("claimReview", [])
    score = 50
    reasons = ["Base score 50 (fact-checks available)"]

    if reviews:
        score += 25
        reasons.append(f"{len(reviews)} claimReview entry(ies) found (+25).")
        bonus = min(15, (len(reviews)-1) * 5)
        if bonus > 0:
            score += bonus
            reasons.append(f"Multiple reviews (+{bonus}).")
        textual = (reviews[0].get("textualRating") or "").lower()
        if any(k in textual for k in ["false", "incorrect", "fabricated", "pants on fire", "misleading"]):
            score += 10
            reasons.append(f"Rating indicates false/misleading (+10): '{reviews[0].get('textualRating')}'.")
        elif any(k in textual for k in ["true", "correct", "accurate"]):
            score += 10
            reasons.append(f"Rating indicates true/corroborated (+10): '{reviews[0].get('textualRating')}'.")
        else:
            reasons.append(f"Neutral/unknown rating: '{reviews[0].get('textualRating')}'. No rating bonus.")
        date_str = reviews[0].get("reviewDate") or reviews[0].get("publishDate") or best.get("claimDate")
        if date_str:
            try:
                dt = dateparser.parse(date_str)
                days_old = (datetime.datetime.utcnow() - dt.replace(tzinfo=None)).days
                if days_old <= 365:
                    score += 5
                    reasons.append(f"Recent fact-check ({days_old} days old) (+5).")
                else:
                    reasons.append(f"Fact-check is older ({days_old} days).")
            except Exception:
                reasons.append("Could not parse fact-check date.")
    else:
        score += 10
        reasons.append("Claim record exists but no claimReview details (+10).")

    score = max(0, min(100, score))
    return score, reasons


def summarize_factcheck_response(fc_json, original_claim):
    claims = fc_json.get("claims", []) if fc_json else []
    if not claims:
        return None
    best = claims[0]
    reviews = best.get("claimReview", [])
    if not reviews:
        return None
    r = reviews[0]
    publisher = r.get("publisher", {}).get("name", "Unknown Source")
    rating = r.get("textualRating") or "No rating"
    url = r.get("url", "")
    title = r.get("title") or r.get("claimReviewed") or ""
    explanation = r.get("alternateName") or ""
    explanation_text = ""
    if "false" in rating.lower() or "incorrect" in rating.lower():
        explanation_text = (
            f"According to {publisher}, this claim is **{rating}**.\n\n"
            f"The available fact-checks state that the information related to '{original_claim}' "
            f"is not supported by any credible evidence. The fact-check notes:\n"
            f"• {title}\n"
        )
    elif "true" in rating.lower():
        explanation_text = (
            f"Fact-checkers from {publisher} rated this **{rating}**.\n\n"
            f"Key point:\n"
            f"• {title}\n"
        )
    else:
        explanation_text = (
            f"{publisher} reviewed this claim and rated it **{rating}**.\n\n"
            f"Details:\n"
            f"• {title}\n"
        )
    explanation_text += f"\nRead full fact-check:\n{url}"
    return explanation_text


# ------------ GOOGLE VISION (REST) ------------
def google_vision_web_detection(image_bytes):
    """Uses Google Vision Web Detection via REST API with ONLY an API key."""
    if not VISION_API_KEY:
        return None
    try:
        url = f"https://vision.googleapis.com/v1/images:annotate?key={VISION_API_KEY}"
        payload = {
            "requests": [
                {
                    "image": {"content": base64.b64encode(image_bytes).decode("utf-8")},
                    "features": [{"type": "WEB_DETECTION"}]
                }
            ]
        }
        r = requests.post(url, json=payload, timeout=15)
        r.raise_for_status()
        data = r.json()
        return data["responses"][0].get("webDetection", None)
    except Exception as e:
        print("Vision API error:", e)
        return None


def fetch_image_bytes(url, timeout=8):
    r = requests.get(url, timeout=timeout, headers={"User-Agent": "Mozilla/5.0"})
    r.raise_for_status()
    return r.content


def detect_malicious_url(url):
    """
    Returns (result_label, details) where result_label in {'malicious','suspicious','clean','unknown'}
    details is a short list of strings explaining the findings.
    Uses Google Safe Browsing Lookup (v4) and heuristics.
    """
    details = []
    # Google Safe Browsing
    if GSAFE_API_KEY:
        try:
            endpoint = f"https://safebrowsing.googleapis.com/v4/threatMatches:find?key={GSAFE_API_KEY}"
            body = {
                "client": {"clientId": "your-app", "clientVersion": "1.0"},
                "threatInfo": {
                    "threatTypes": ["MALWARE", "SOCIAL_ENGINEERING", "UNWANTED_SOFTWARE", "POTENTIALLY_HARMFUL_APPLICATION"],
                    "platformTypes": ["ANY_PLATFORM"],
                    "threatEntryTypes": ["URL"],
                    "threatEntries": [{"url": url}]
                }
            }
            r = requests.post(endpoint, json=body, timeout=6)
            if r.status_code == 200:
                data = r.json()
                if data.get("matches"):
                    details.append("Google Safe Browsing: matched threat list.")
                    for m in data["matches"]:
                        details.append(f"{m.get('threatType')}")
                    return "malicious", details
                else:
                    details.append("Google Safe Browsing: no matches.")
            else:
                details.append(f"SafeBrowsing API error {r.status_code}")
        except Exception as e:
            details.append(f"SafeBrowsing error: {e}")

    # Heuristics
    try:
        domain = tldextract.extract(url).registered_domain or url
        if domain.count("-") > 3 or any(x in domain.lower() for x in ["-free", "login", "verify", "secure"]):
            details.append("Domain heuristics flagged suspicious tokens in domain.")
            return "suspicious", details
    except Exception:
        pass

    if details:
        # if details exist but none indicate "malicious", treat as unknown/clean
        if all(("no match" in d.lower() or "clean" in d.lower() or "0" in d.lower()) for d in details):
            return "clean", details
        return "unknown", details

    return "unknown", ["No API keys configured, limited checks done."]


def detect_fake_image(image_url, image_bytes=None):
    """
    Fake-image detection using:
    - EXIF analysis
    - Perceptual hash (pHash)
    - Local hoax hash DB (KNOWN_IMAGE_HASHES)
    - Google Vision Web Detection (API key)
    Accepts image_bytes to avoid double-fetch.
    """
    details = []
    # Fetch image only if bytes not provided
    try:
        if image_bytes is None:
            image_bytes = fetch_image_bytes(image_url)
        img = Image.open(io.BytesIO(image_bytes)).convert("RGB")
    except Exception as e:
        return "uncertain", [f"Could not fetch/process image: {e}"]

    # EXIF
    try:
        exif = img._getexif()
        if exif:
            details.append("EXIF metadata present.")
        else:
            details.append("No EXIF metadata.")
    except Exception:
        details.append("EXIF parse error or missing.")

    # pHash
    try:
        phash = imagehash.phash(img)
        phash_hex = str(phash)
        details.append(f"pHash = {phash_hex}")
        for known_hash, info in KNOWN_IMAGE_HASHES.items():
            try:
                hd = phash - imagehash.hex_to_hash(known_hash)
            except Exception:
                continue
            if hd <= 6:
                details.append(f"Matches known hoax image ({info.get('label')}) hd={hd}")
                return "known-hoax", details
    except Exception as e:
        details.append(f"pHash error: {e}")

    # Vision Web Detection
    web_data = google_vision_web_detection(image_bytes)
    if web_data:
        best_guesses = web_data.get("bestGuessLabels", [])
        if best_guesses:
            guess = best_guesses[0].get("label", "").lower()
            details.append(f"Vision Best Guess: {guess}")
            if any(x in guess for x in ["manipulated", "fake", "hoax", "edited"]):
                details.append("Vision suggests image manipulation.")
                return "likely-manipulated", details
        pages = web_data.get("pagesWithMatchingImages", [])
        for p in pages:
            url_found = p.get("url", "")
            details.append(f"Found matching image on: {url_found}")
            if any(x in url_found.lower() for x in ["altnews", "snopes", "boomlive", "factcheck", "politifact"]):
                return "known-hoax", details

    details.append("No manipulation detected from available checks.")
    return "clean", details


# ------------ MAIN WEBHOOK ENDPOINT ------------
@app.route("/webhook", methods=["POST"])
def webhook():
    incoming_msg = request.values.get("Body", "").strip()
    from_number = request.values.get("From", "")
    print(f"Message from {from_number}: {incoming_msg}")

    resp = MessagingResponse()
    reply = resp.message()

    # ---- MEDIA (IMAGE) HANDLING ----
    num_media = int(request.values.get("NumMedia", "0"))
    if num_media > 0:
        for i in range(num_media):
            media_url = request.values.get(f"MediaUrl{i}")
            media_type = request.values.get(f"MediaContentType{i}", "")

            if media_type.startswith("image"):
                # fetch bytes once
                try:
                    image_bytes = fetch_image_bytes(media_url)
                except Exception as e:
                    reply.body("Could not fetch image for analysis: " + str(e))
                    return str(resp)

                label, det = detect_fake_image(media_url, image_bytes=image_bytes)

                # Save image & analysis text via data_store
                try:
                    saved_img = save_image_file(image_bytes, media_url)
                    saved_txt = save_analysis_text("\n".join(det), saved_img)
                except Exception as e:
                    saved_img, saved_txt = "", ""
                    print("Saving media error:", e)

                # Log image entry
                try:
                    log_image_entry(
                        from_number=from_number,
                        original_text=incoming_msg,
                        image_url=media_url,
                        image_label=label,
                        details=det,
                        saved_image_path=saved_img,
                        saved_text_path=saved_txt
                    )
                except Exception as e:
                    print("Logging image entry error:", e)

                # Reply and return
                reply_text = f"🖼️ Image analysis result: {label}\n\n" + "\n".join(det[:6])
                reply.body(reply_text)
                return str(resp)
            else:
                reply.body("Received media, but only images are analyzed currently.")
                return str(resp)

    # ---- URL SAFETY CHECK ----
    urls = URL_RE.findall(incoming_msg)
    if urls:
        for u in urls:
            label, det = detect_malicious_url(u)
            # Log URL result
            try:
                log_url_entry(from_number=from_number, original_text=incoming_msg, url=u, label=label, details=det)
            except Exception as e:
                print("Logging URL entry error:", e)

            # If malicious or suspicious -> warn and stop further processing
            if label in ["malicious", "suspicious"]:
                reply.body(f"⚠️ URL safety check: {label}\n" + "\n".join(det[:6]) + f"\n\nLink: {u}")
                return str(resp)
        # If none were malicious, include a short note — do not return yet; proceed to fact-check
        # (Optionally you can reply with url safety OK here; we proceed)

    # If message empty (and no media), prompt user
    if not incoming_msg:
        reply.body("Send a message, news link, or claim to check.")
        return str(resp)

    claim = incoming_msg

    # --- Try Google FactCheck API ---
    fc = query_google_factchecks(claim)
    if fc:
        summary = summarize_factcheck_response(fc, claim)
        confidence, reasons = compute_confidence_from_factcheck(fc)
        # Map label
        if confidence >= 71:
            confidence_label = "High"
        elif confidence >= 41:
            confidence_label = "Medium"
        else:
            confidence_label = "Low"

        # Log text entry
        try:
            log_text_entry(
                from_number=from_number,
                text=incoming_msg,
                urls=urls,
                fact_summary=summary,
                confidence=confidence,
                confidence_label=confidence_label
            )
        except Exception as e:
            print("Logging text entry error:", e)

        # Compose reply: include summary + confidence + brief breakdown
        breakdown = "\n".join([f"• {r}" for r in reasons[:6]])
        reply_text = f"Fact-check found:\n\n{summary}\n\nConfidence: {confidence}% ({confidence_label})\n{breakdown}"
        reply.body(reply_text)
        return str(resp)

    # --- If URL present and no fact-check found, show page title heuristic ---
    if urls:
        try:
            page = requests.get(urls[0], timeout=8, headers={"User-Agent": "Mozilla/5.0"})
            title_match = re.search(r"<title>(.*?)</title>", page.text, re.IGNORECASE | re.DOTALL)
            title = title_match.group(1).strip() if title_match else urls[0]
            # Log as a text entry with low confidence (no fact-check)
            try:
                log_text_entry(
                    from_number=from_number,
                    text=incoming_msg,
                    urls=urls,
                    fact_summary=f"URL fetched title: {title}",
                    confidence=25,
                    confidence_label="Low"
                )
            except Exception as e:
                print("Logging text entry (url title) error:", e)

            reply.body(f"URL detected: {title}\n\nNo authoritative fact-check found yet.")
            return str(resp)
        except Exception:
            reply.body("I found a link but couldn't access it. Checking text instead…")

    # --- No matches / fallback verdict ---
    # Log as unverified text
    try:
        log_text_entry(
            from_number=from_number,
            text=incoming_msg,
            urls=urls,
            fact_summary="No fact-check found",
            confidence=25,
            confidence_label="Low"
        )
    except Exception as e:
        print("Logging fallback text entry error:", e)

    reply.body("No fact-check found.\nVerdict: *UNVERIFIED*\n\nTry sending:\n• Full URL\n• A clearer claim\n• A screenshot (image support available)")
    return str(resp)


# ------------ HEALTH CHECK ENDPOINT (OPTIONAL) ------------
@app.route("/healthz", methods=["GET"])
def health():
    return "OK", 200


# ------------ MAIN ------------
if __name__ == "__main__":
    # IMPORTANT: for ngrok, bind to 0.0.0.0
    app.run(host="0.0.0.0", port=5000, debug=True)
