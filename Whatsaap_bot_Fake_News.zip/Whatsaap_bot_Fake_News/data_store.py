# data_store.py
# Handles: CSV logging, Excel export, image saving, text-summary saving.

import os
import csv
import uuid
import datetime
from pathlib import Path
from filelock import FileLock
import pandas as pd

# ==== DIRECTORY STRUCTURE ====
BASE_DIR = Path.cwd()
DATA_DIR = BASE_DIR / "saved_data"
MEDIA_DIR = BASE_DIR / "saved_media"
IMAGES_DIR = MEDIA_DIR / "images"
TEXTS_DIR = MEDIA_DIR / "texts"

DATA_DIR.mkdir(parents=True, exist_ok=True)
IMAGES_DIR.mkdir(parents=True, exist_ok=True)
TEXTS_DIR.mkdir(parents=True, exist_ok=True)

CSV_FILE = DATA_DIR / "data.csv"
XLSX_FILE = DATA_DIR / "data.xlsx"
LOCK_FILE = DATA_DIR / "data.lock"

# ==== CSV HEADER (created on first run) ====
COLUMNS = [
    "id",
    "timestamp_utc",
    "from_number",
    "type",
    "original_text",
    "urls",
    "media_urls",
    "factcheck_summary",
    "confidence_pct",
    "confidence_label",
    "image_label",
    "image_details",
    "url_label",
    "url_details",
    "extra_notes",
]

if not CSV_FILE.exists():
    with CSV_FILE.open("w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(COLUMNS)

def now_iso():
    return datetime.datetime.utcnow().replace(microsecond=0).isoformat() + "Z"

# ===================================================================
# =============== IMAGE FILE SAVING =================================
# ===================================================================
def save_image_file(image_bytes, original_url):
    """Saves the image bytes to disk with a unique filename."""
    ts = datetime.datetime.utcnow().strftime("%Y%m%d_%H%M%S")
    unique = uuid.uuid4().hex[:8]

    ext = ".jpg"
    if "." in original_url:
        maybe_ext = original_url.split(".")[-1]
        if len(maybe_ext) <= 5:
            ext = "." + maybe_ext

    filename = f"img_{ts}_{unique}{ext}"
    image_path = IMAGES_DIR / filename

    with image_path.open("wb") as f:
        f.write(image_bytes)

    return str(image_path)

def save_analysis_text(text, image_path):
    """Creates a .txt file with same base name as the saved image."""
    base = Path(image_path).stem
    text_filename = base + ".txt"
    text_path = TEXTS_DIR / text_filename

    with text_path.open("w", encoding="utf-8") as f:
        f.write(text)

    return str(text_path)

# ===================================================================
# =============== CSV + EXCEL WRITING ================================
# ===================================================================
def append_row(row: dict):
    """Append one row safely into CSV + regenerate Excel snapshot."""
    lock = FileLock(str(LOCK_FILE))
    with lock.acquire(timeout=10):
        with CSV_FILE.open("a", newline="", encoding="utf-8") as f:
            writer = csv.writer(f)
            writer.writerow([row.get(col, "") for col in COLUMNS])

        # Excel snapshot
        try:
            df = pd.read_csv(CSV_FILE)
            df.to_excel(XLSX_FILE, index=False, engine="openpyxl")
        except Exception as e:
            print("Excel write error:", e)


# ===================================================================
# =============== PUBLIC LOGGING FUNCTIONS ===========================
# ===================================================================

def log_text_entry(from_number, text, urls, fact_summary, confidence, confidence_label):
    """Log a text claim & fact-check response."""
    row = {
        "id": uuid.uuid4().hex,
        "timestamp_utc": now_iso(),
        "from_number": from_number,
        "type": "text",
        "original_text": text,
        "urls": ",".join(urls) if urls else "",
        "media_urls": "",
        "factcheck_summary": fact_summary.replace("\n", " || ") if fact_summary else "",
        "confidence_pct": confidence,
        "confidence_label": confidence_label,
        "image_label": "",
        "image_details": "",
        "url_label": "",
        "url_details": "",
        "extra_notes": ""
    }
    append_row(row)


def log_image_entry(from_number, original_text, image_url, image_label, details, saved_image_path, saved_text_path):
    """Log an image + analysis into CSV."""
    row = {
        "id": uuid.uuid4().hex,
        "timestamp_utc": now_iso(),
        "from_number": from_number,
        "type": "image",
        "original_text": original_text,
        "urls": "",
        "media_urls": image_url,
        "factcheck_summary": "",
        "confidence_pct": "",
        "confidence_label": "",
        "image_label": image_label,
        "image_details": ";".join(details[:6]),
        "url_label": "",
        "url_details": "",
        "extra_notes": f"image_path={saved_image_path};analysis_path={saved_text_path}"
    }
    append_row(row)


def log_url_entry(from_number, original_text, url, label, details):
    """Log URL safety result."""
    row = {
        "id": uuid.uuid4().hex,
        "timestamp_utc": now_iso(),
        "from_number": from_number,
        "type": "url",
        "original_text": original_text,
        "urls": url,
        "media_urls": "",
        "factcheck_summary": "",
        "confidence_pct": "",
        "confidence_label": "",
        "image_label": "",
        "image_details": "",
        "url_label": label,
        "url_details": ";".join(details[:6]),
        "extra_notes": ""
    }
    append_row(row)
